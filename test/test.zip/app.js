/**
 * Created with JetBrains WebStorm.
 * User: luckystar
 * Date: 13-4-7
 * Time: 下午5:38
 * To change this template use File | Settings | File Templates.
 */

var express = require('express')
    , app = express()
    , expressValidator = require('express-validator')
    , server = require('http').createServer(app)
    , util = require('util')
    , io = require('socket.io').listen(server);

io.enable('browser client minification');  // send minified client
io.enable('browser client etag');          // apply etag caching logic based on version number
io.enable('browser client gzip');          // gzip the file
//io.set('log level', 1);                    // reduce logging

app.configure(function () {
    app.use("/client", express.directory(__dirname + "/../client"));
    app.use("/client", express["static"](__dirname + "/../client"));

    app.use("/client", express.directory(__dirname + "/client"));
    app.use("/client", express["static"](__dirname + "/client"));

    app.use("/uploads", express.directory(__dirname + "/uploads"));
    app.use("/uploads", express["static"](__dirname + "/uploads"));
   
    app.use(express.logger());
    app.use(express.bodyParser({
        "keepExtensions":true,
        "uploadDir":__dirname + "/uploads"
    }));
    app.use(expressValidator());
    app.use(require('./routes/requestParamChecker'));

    require("./routes")(app);

    app.use(function (err, req, res, next) {
        //console.log('err: %s', util.inspect(err));
        console.log('app.js/43 err: %s', JSON.stringify(err));
        res.send(err.statusCode || 500, err.error);
    });
});


app.configure("development", function () {
    app.use(express.errorHandler({
        dumpExceptions:true,
        showStack:true
    }));
});

app.configure("production", function () {
    app.use(express.errorHandler());
});

server.listen(3000);

require('./socket/socket')(io);


