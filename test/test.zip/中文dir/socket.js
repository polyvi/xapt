/**
 * Created with JetBrains WebStorm.
 * User: luckystar
 * Date: 13-6-24
 * Time: 下午4:37
 * To change this template use File | Settings | File Templates.
 */
var util = require('util'),
    _ = require('underscore');

var User = require('../models/User'),
    CanvasRoom = require('../models/CanvasRoom');

var Socket = {
    //quick messages 1-9用于快速消息，不可使用0，因为client端checkParam时，0会自动转换为false
    CANVAS_LINE_TO:1
}

module.exports = function (io) {
    io.sockets.on('connection', function (socket) {
        function canvasDo(action, data) {
            if (socket.canvasRoom)
                socket.canvasRoom.do({action:action, userShortId:socket.userShortId, data:data});
        }

        socket.on('setUser', function (user) {
            socket.user = user;
            //每个用户建一个socketRoom，用于相同账号用户间广播消息
            socket.join(user._id);
        });

        socket.on('canvasJoin', function (roomName) {
            CanvasRoom.getRoom(roomName, io).join(socket);
            canvasDo('canvasJoin', socket.user);
        });

        socket.on('canvasLeave', function () {
            socket.canvasRoom.leave(socket);
        });

        socket.on('disconnect', function () {
            //leave();
        });

        function leave() {
            if (!socket.canvasRoom) return;
            socket.canvasRoom.leave(user);
            var clients = io.sockets.clients('room1');
            if (clients.length == 0) {
                delete rooms[socket.canvasRoom];
            }

            canvasDo('canvasLeave');
        }

        socket.on(Socket.CANVAS_LINE_TO, function (data) {
            canvasDo(Socket.CANVAS_LINE_TO, data);
        });

        socket.on('canvasMoveTo', function (data) {
            canvasDo('canvasMoveTo', data);
        });

        socket.on('canvasStrokeWidth', function (data) {
            canvasDo('canvasStrokeWidth', data);
        });

        socket.on('canvasStrokeColor', function (data) {
            canvasDo('canvasStrokeColor', data);
        });

        socket.on('canvasDrawImage', function (data) {
            canvasDo('canvasDrawImage', data);
        });

        socket.on('canvasStart', function (data) {
            canvasDo('canvasStart', data);
        });

        socket.on('canvasEnd', function (data) {
            canvasDo('canvasEnd', data);
        });

        //视频播放Movie
        socket.on('moviePlay', function (data) {
            //exclude sender
            socket.broadcast.to(socket.user._id).emit('moviePlay', data);
        });
    });
};


