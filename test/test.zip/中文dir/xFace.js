var bens = {
    //删除左右两端的空格
    trim:function(str){
        return str.replace(/(^\s*)|(\s*$)/g, "");
    },
    //删除左边的空格
    ltrim:function(str){
        return str.replace(/(^\s*)/g,"");
    },
    //删除右边的空格
    rtrim:function(str){
        return str.replace(/(\s*$)/g,"");
    },
    //时间戳转时间
    stamp2time:function(b){             //stamp2time和time2stamp   2个时间转换的毫秒数会被忽略。
        var a = new Date(parseInt(b));
        var year=a.getFullYear();
        var month=parseInt(a.getMonth())+1;
        month= (month<10)? "0"+month : month;
        var date=a.getDate();
        date= (date<10)? "0"+date : date;
        var hours=a.getHours();
        hours= (hours<10)? "0"+hours : hours;
        var minutes=a.getMinutes();
        minutes= (minutes<10)? "0"+minutes : minutes;
        var seconds=a.getSeconds();
        seconds= (seconds<10)? "0"+seconds : seconds;

        return year+"-"+month+"-"+date+" "+hours+":"+minutes+":"+seconds;
    },
    time2stamp:function(a){    //a :   2012-12-13   2012-12-12 12:12:33  自动补位
        var new_str = a.replace(/:/g,'-');
        new_str = new_str.replace(/ /g,'-');
        new_str = new_str.replace(/ /g,'-');
        var arr = new_str.split("-");
        if(arr.length != 6){
            for(var i= 0,l=6-arr.length;i<l;i++){
                arr.push(0);
            }
        }

        return new Date(Date.UTC(arr[0],arr[1]-1,arr[2],arr[3]-8,arr[4],arr[5])).getTime();
    },
    //获取原生dom   obj=id、jq对象、dom对象会成功 ， 其它失败
    getDom:function(obj){
        var returnobj;

        if(!obj){return returnobj;}

        if($.isString(obj)){
            returnobj = document.getElementById(obj);
        }else if($.isObject(obj)){
            if($.is$(obj)){
                returnobj = obj.get(0);
            }
            if(obj.nodeType == 1){
                returnobj = obj;
            }
        }

        return returnobj;
    },
    //检查fn，是返回fn 否返回空函数
    getFunction:function(fn){
        return ($.isFunction(fn))? fn : function(){};
    },
    //检查并返回对象
    getObj:function(obj){
        return ($.isObject(obj))? obj : {};
    },
    //克隆json或数组(只能是纯数据)
    cloneDate:function(obj){
        return JSON.parse(JSON.stringify(obj));
    },
    //图片在容器中的大小计算
    getNewImageSize:function(imgwidth,imgheight,objwidth,objheight){
        var newimgwidth,newimgheight;

        if(imgwidth>0 && imgheight>0){
            if(imgwidth/imgheight>=objwidth/objheight){
                if(imgwidth>objwidth){
                    newimgwidth = objwidth;
                    newimgheight = imgheight*objwidth/imgwidth;
                }else{
                    newimgwidth = imgwidth;
                    newimgheight = imgheight;
                }
            }else{
                if(imgheight>objheight){
                    newimgheight = objheight;
                    newimgwidth = imgwidth*objheight/imgheight;
                }else{
                    newimgwidth = imgwidth;
                    newimgheight = imgheight;
                }
            }
        }

        return {
            width:newimgwidth,
            height:newimgheight
        }
    }
};


//动态加载插件  //需要 jq.mobi
(function(){
    var save={};
    bens.require = function (filename){
        if(!save[filename]){
            var timestamp = new Date().getTime();
            $.ajax({
                type:"get",
                contentType:'application/json;charset="UTF-8"',
                async:false,
                cache:false,
                url:"js/plug/"+filename+".js?id="+timestamp,   //文件地址
                //url:"js/plug/"+filename+".js",   //文件地址
                dataType:"script",
                success:function(data){
                    save[filename] = eval(data);      //插件需要自执行函数并返回对象
                },
                error:function(){
                    console.log(filename+"：加载失败！");
                }
            });
        }
        return save[filename];
    };
})();

//加载文件到页面(有特有属性  add_type=“ajax”)
bens.loadFile = (function(){
    var jsFile = function(file,callback){
            var head = document.getElementsByTagName('HEAD').item(0);
            var script = document.createElement('SCRIPT');
            script.src = file+"?s="+new Date().getTime();
            script.charset = "utf-8";
            script.type = "text/javascript";
            script.add_type = "ajax";
            head.appendChild(script);

            script.onload = script.onreadystatechange = function(){
                if(!this.readyState || this.readyState=='loaded' || this.readyState=='complete'){
                    if(typeof(callback)=="function"){
                        callback();
                    }
                }
                script.onload=script.onreadystatechange=null;
            }
        },
        jsText = function(text,callback){
            //$.post(file+"?s="+new Date().getTime(),function(data){
            var head = document.getElementsByTagName('HEAD').item(0);
            var script = document.createElement('SCRIPT');
            script.type = "text/javascript";
            script.charset = "utf-8";
            script.defer = true;
            script.text = text;
            head.appendChild(script);

            if(typeof(callback)=="function"){
                callback();
            }
            //})

        },
        cssFile = function(file,callback){
            var head = document.getElementsByTagName('HEAD').item(0);
            var css = document.createElement('link');
            css.rel = "stylesheet";
            css.type = "text/css";
            css.href = file+"?s="+new Date().getTime();
            css.add_type = "ajax";
            head.appendChild(css);


            var  styleOnload=function(node, callback) {
                // for IE6-9 and Opera
                if (node.attachEvent) {
                    node.attachEvent('onload', callback);
                    // NOTICE:
                    // 1. "onload" will be fired in IE6-9 when the file is 404, but in
                    // this situation, Opera does nothing, so fallback to timeout.
                    // 2. "onerror" doesn't fire in any browsers!
                }
                // polling for Firefox, Chrome, Safari
                else {
                    setTimeout(function() {
                        poll(node, callback);
                    }, 0); // for cache
                }
            };

            var poll=function(node, callback) {
                if (callback.isCalled) {
                    return;
                }

                var isLoaded = false;

                if (/webkit/i.test(navigator.userAgent)) {//webkit
                    if (node['sheet']) {
                        isLoaded = true;
                    }
                }
                // for Firefox
                else if (node['sheet']) {
                    try {
                        if (node['sheet'].cssRules) {
                            isLoaded = true;
                        }
                    } catch (ex) {
                        // NS_ERROR_DOM_SECURITY_ERR
                        if (ex.code === 1000) {
                            isLoaded = true;
                        }
                    }
                }

                if (isLoaded) {
                    // give time to render.
                    setTimeout(function() {
                        callback();
                    }, 1);
                }
                else {
                    setTimeout(function() {
                        poll(node, callback);
                    }, 1);
                }
            };

            styleOnload(css,function(){
                if(typeof(callback)=="function"){
                    callback();
                }
            });
        },
        htmlFile = function(id,file,callback){
            $.get(file+"?s="+new Date().getTime(),function(data){
                if(typeof(callback)=="function"){
                    $("#"+id).html(data);
                    callback();
                }
            })
        };

    return function(datas){
        var jsfile = datas.js || [],
            cssfile = datas.css || [],
            htmlfile = datas.html || [],
            htmlid = datas.htmlId || [],
            success = datas.success;

        if($.isArray(jsfile) ){}else{return;}
        if($.isArray(cssfile) ){}else{return;}
        if($.isArray(htmlfile) ){}else{return;}
        if($.isArray(htmlid) ){}else{return;}
        if(htmlfile.length != htmlid.length){return;}
        success = ( typeof(success) == "function") ? success : function(){};

        var filse = jsfile.length + cssfile.length + htmlfile.length,
            loaded = 0,
            loadsuccess = function (){
                loaded++;
                if(filse == loaded){
                    //load complete
                    success();
                }
            };
        if(filse == 0){return;}

        for (var i= 0,l=jsfile.length;i<l;i++){
            jsFile(jsfile[i],loadsuccess);
        }
        for (var i= 0,l=cssfile.length;i<l;i++){
            cssFile(cssfile[i],loadsuccess);
        }
        for (var i= 0,l=htmlfile.length;i<l;i++){
            htmlFile(htmlid[i],htmlfile[i],loadsuccess);
        }
    };
})();



//数组扩展======================================================================================================

//将一个数组添加到另一个数组末尾  会改变原数组
Array.prototype.pushArray = function(b){
    this.push.apply(this,b);
    return this;
};
//获取数组中的最大值  数组中不能有字母或对象   null,false转换为1  true转换为2   可以filter（function）后在求值
Array.prototype.findMax= function(){
    return Math.max.apply(null,this);
};
//获取数组中的最小值 数组中不能有字母
Array.prototype.findMin= function(){
    return Math.min.apply(null,this);
};
//数组排序  按数字大小   默认是按字符排序
Array.prototype.sortByNumber= function(type){
    if(type == "desc"){
        this.sort(function(a,b){ return (a>b)? -1 : 1; });
    }else{
        this.sort(function(a,b){ return (a>b)? 1 : -1; });
    }
    return this;
};
//数组排序  中文    数组中如果是对象使用key,否则传空   type默认从小到大，desc反序
Array.prototype.sortByChine= function(key,type){
    this.sort(function(a,b){
        if(key){
            a = a[key];
            b = b[key];
        }
        a = a.toString();
        b = b.toString();

        if(type == "desc"){
            return b.localeCompare(a);
        }else{
            return a.localeCompare(b);
        }
    });

    return this;
};
//删除数组中的重复值  只会返回字符和数字的不重复数组
//注意：不会改变原数组 并返回的数组中全是字符串
Array.prototype.delReplace = function(){
    var array = this,
        t_json = {},
        n_array = [];

    for(var i= 0,l=array.length;i<l;i++){
        var thisdata = array[i];
        if(typeof(thisdata) === "object"){

        }else{
            t_json[thisdata] = thisdata;
        }
    }

    for(var key in t_json){
        n_array.push(key);
    }

    return n_array;
};


//删除数组中的一个值 用原生的filter方法返回新数组  不写了
//  array.filter(function(a,index){if(a!=3){return a;}})


